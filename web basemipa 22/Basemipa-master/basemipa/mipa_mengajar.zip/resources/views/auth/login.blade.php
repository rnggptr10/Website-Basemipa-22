<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Login {{ config('app.name') }}</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="{{ asset('img/favicon.ico') }}" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="{{ asset('atlantis/js/plugin/webfont/webfont.min.js') }}"></script>
    <script>
        WebFont.load({
            google: {
                "families": ["Lato:300,400,700,900"]
            },
            custom: {
                "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"],
                urls: ['{{ asset('
                    atlantis / css / fonts.min.css ') }}'
                ]
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="{{ asset('atlantis/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('atlantis/css/atlantis.css') }}">
</head>

<body class="login">
    <div class="wrapper wrapper-login wrapper-login-full p-0" style="background-color: #efefed;">
        <div class="login-aside w-50 d-flex flex-column align-items-center justify-content-center text-center">

            <div class="container">
                <div class="row">
                    <div class="col d-flex align-items-center justify-content-end">
                        <img src="{{ asset('img/logo/unpad.png') }}" alt="" style="width: 5em; height:4em;">
                    </div>
                    <div class="col-3 d-flex align-items-center justify-content-center">
                        <img src="{{ asset('img/logo/lg_00.png') }}" alt="" style="width: 5em; height:5em;">
                    </div>
                    <div class="col d-flex align-items-center justify-content-start">
                        <img src="{{ asset('img/logo/bem.png') }}" alt="" style="width: 5em; height:5em;">
                    </div>
                </div>
            </div>

            <div>
                <br>
                <h1 style="color: #742012; ">
                    WEBSITE DATABASE KEMA
                </h1>
            </div>
            <div>
                <img src="{{ asset('img/logo/Aksikarsa.png') }}" alt="" style="width: 40em; height:22.5em;">
            </div>

            <div>
                <h2 style="color: #742012;">
                    BIRO RISET DATA
                    <br>
                    BEM KEMA FMIPA UNPAD
                    <br>
                    KABINET AKSIKARSA 2021
                </h2>
            </div>

            <div style="color:#742012; opacity:0.7;">
                #RangkaiCeritaUntukAksiNyata
            </div>


        </div>
        <div class="login-aside w-50 d-flex align-items-center justify-content-center bg-white">
            <div class="container container-login container-transparent animated fadeIn">
                <h3 class="text-center">Login</h3>

                <form action="{{ route('login') }}" method="post" autocomplete="off">

                    @csrf

                    <div class="login-form">
                        <div class="form-group">
                            <label for="username" class="placeholder"><b>Username</b></label>
                            <input class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" placeholder="{{ __('username') }}" type="text" name="username" value="{{ old('username') }}" value="admin@argon.com" required autofocus>
                            @if ($errors->has('username'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('username') }}</strong>
                            </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="password" class="placeholder"><b>Password</b></label>
                            <!--<a href="{{ route('password.request') }}" class="link float-right">Lupa Password ?</a>-->
                            <div class="position-relative">
                                <input class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="{{ __('Password') }}" type="password" value="secret" required>
                                <div class="show-password">
                                    <i class="icon-eye"></i>
                                </div>
                            </div>
                        </div>
                        <div class="form-group form-action-d-flex mb-3">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" name="remember" id="rememberme">
                                <label class="custom-control-label m-0" for="rememberme">Remember Me</label>
                            </div>
                            <button class="btn col-md-5 float-right mt-3 mt-sm-0 fw-bold" style="background-color:#e83b3a; border-color:#e83b3a; color:white;">Log In</button>
                        </div>

                        <!-- SIGN UP FEATURE -->
                        <!--<div class="login-account">-->
                        <!--    <span class="msg">Belum punya akun?</span>-->
                        <!--    <a href="{{ url('/register') }}" id="show-signup" class="link">Sign Up</a>-->
                        <!--</div>-->

                    </div>

                </form>

            </div>
        </div>
    </div>
    <script src="{{ asset('atlantis/js/core/jquery.3.2.1.min.js') }}"></script>
    <script src="{{ asset('atlantis/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('atlantis/js/core/popper.min.js') }}"></script>
    <script src="{{ asset('atlantis/js/core/bootstrap.min.js') }}"></script>
    <script src="{{ asset('atlantis/js/atlantis.min.js') }}"></script>
</body>

</html>