<?php

namespace App\Http\Controllers;

use App\Osean;
use App\MipaMengajar;
// use App\Http\Requests\UserRequest;
// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Hash;

class KepanitiaanController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function osean()
    {
        $kepanitiaans = Osean::all();
        return view('kepanitiaan', compact('kepanitiaans'));
    }

    public function mipaMengajar()
    {
        $kepanitiaans = MipaMengajar::all();
        return view('kepanitiaan', compact('kepanitiaans'));
    }
}
